/**
 Luke Pulaski
 CS 110

 The GameDriver class creates a new Yahtzee game and runs it

 NOTE: This is my second submission. I am being graded for the May 5 submission, not May 3.
 */

public class GameDriver
{
    public static void main(String [] args)
    {
        Game g = new Game();
        g.playGame();
    }
}
