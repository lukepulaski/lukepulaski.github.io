Thank you for your interest in my CS 110 Final Project!

The entire class was assigned the task of building Yahtzee that is playable in the Java shell.

If you are interested in playing, open and run the file 'GameDriver.java'.

If you have never played Yahtzee before, that's okay. I've linked the official instructions below:
https://instructions.hasbro.com/api/download/00950_en-ca_yahtzee-classic.pdf

I hope you enjoy!
