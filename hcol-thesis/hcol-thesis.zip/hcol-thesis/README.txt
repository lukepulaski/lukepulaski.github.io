
Thank you for your interest in my thesis!


Since the time of publication, it has come to my attention that there are two small errors in Section 7: Robustness Checks, which I've listed below.


p. 34: "In Tables 10, 11(a), and 11(b), I will refer to this variable as “LPR_CHANGE”."

---> I meant to refer to Tables 11, 13(a), and 13(b), not 10, 11(a), and 11(b).


p. 35: "So, to obtain a more accurate comparison between the two measures of immigrant inflow, I
also regress housing market outcomes on immigrant inflow relative to population (labeled as
“IMMIGRATION” in Table 11 and Tables 12(a) and 12(b)) using the same sample of 46 MSAs. I
recalculate the U.S.-level instrument accordingly and apply it to the immigration variable."

---> I meant to refer to Tables 13(a) and 13(b), not 12(a) and 12(b).


Hopefully these errors do not cause too much of an inconvenience. I hope you enjoy the paper!